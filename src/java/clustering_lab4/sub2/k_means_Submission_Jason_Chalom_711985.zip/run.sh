#!/bin/bash
clear
clear
"C:\Program Files\Java\jdk1.8.0_74\bin\javac.exe" k_means.java
java k_means DatasetH4.txt results.txt